# term-project

### Project name: Bridge Buddy

## How to run:

The code is run from the 'main.py' 

The 'media' folder should contain the following files:
* button_click.wav
* cards.png
* image1.jpg
* image5.jpg
* music.mp3
* nature.mp3
* play_card.wav

### Necessary Modules:
* pygame

## Media citation

The file "french_cards.png" is obtained from https://commons.wikimedia.org/wiki/File:Svg-cards-2.0.svg

button_click.wav is from https://creatorassets.com/a/button-sound-effects (sound 2) via https://www.online-convert.com/

play_card.wav from https://www.youtube.com/watch?v=VGMmaGY_EKE via https://youtube-converter.online/

music.mp3 is The Golden Present from Jesse Gallagher 
nature.mp3 is Jungle Atmosphere Afternoon 
both from Youtube Audio Library

music in the demo video from Buccaneer’s March by Aakash Gandhi also from the Youtube Audio Library

color palatte from https://coolors.co

menu overlay images from https://commons.wikimedia.org/wiki/File:Sorting_the_Cards_(14523861902).jpg and https://commons.wikimedia.org/wiki/File:A_face-up_deck_of_cards.jpg with some edits by me
