# term-project



The file "french_cards.png" is obtained from https://commons.wikimedia.org/wiki/File:Svg-cards-2.0.svg


button click from https://creatorassets.com/a/button-sound-effects (sound 2) via https://www.online-convert.com/

card sound effect from https://www.youtube.com/watch?v=VGMmaGY_EKE via https://youtube-converter.online/


bidding box from https://commons.wikimedia.org/wiki/File:Bidding_box.png

ambient song is The Golden Present from Jesse Gallagher 
nature sound is Jungle Atmosphere Afternoon 
both from Youtube Audio Library

